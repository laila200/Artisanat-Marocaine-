<?php

namespace App\Http\Controllers;


use App\Models\Product;
use App\Models\Cart;
use Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\UserAuthController;
use App\Models\User;
use App\Models\userprod;
use Srmklive\PayPal\Services\ExpressCheckout; 
use App\Models\order;

use App\Paypal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use PayPal\Api\Amount;
use PayPal\Api\Details;
use PayPal\Api\Item;
use PayPal\Api\ItemList;
use PayPal\Api\Payer;
use PayPal\Api\Payment;
use PayPal\Api\PaymentExecution;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Transaction;
use PayPal\Auth\OAuthTokenCredential;
use PayPal\Rest\ApiContext;
use Redirect;
use URL;


class ProductController extends Controller
{
    function index()
    {
        
        $data=Product::all();

        return view('admin.product',['products'=>$data]);
    }
    function search(Request $req)
    { $data=Product::where('category',$req->input('ga'))->get();
        return view('admin.product',['products'=>$data]);
    }
   
    function detail($id)
    {
        $products =Product::find($id);
        return  view ('detail',['products'=>$products]); 
    }
    function  addToCart(Request $req)
    {
        if($req->Session()->has('LoggedUser'))
         {
            $cart=new Cart;
          
            $cart->user_id=$req->Session()->get('LoggedUser')['id'];
            $cart->product_id=$req->product_id;
            $cart->Qtt= $req->Qtt;
            $cart->save();
            return redirect('/index');
           
        }else 
        {
            return redirect('/login');
        }
    }
    function editcart(Request $req,$id)
     {
       
           $cart=Cart::find($id);
           $cart->Qtt= $req->Qtt;
           $cart->save();
           return redirect('/cartList');
          
       
    
         return redirect('/listPro')->with('products',$products);
     }
    static function cartItem()
    {
        // .Auth::id()
        $userId=Session::get('LoggedUser')['id'];
        return Cart::where('user_id',$userId)->count();
    }
    public  function remove($id)
    {
        Cart::destroy($id);
        return redirect('cartList') ; 
    }
        function cartList()
        {
           
            $userId=Session::get('LoggedUser')['id'];
            $products=DB::table('cart')
            ->join('products','cart.product_id','=','products.id')
            ->where('cart.user_id',$userId)
            ->select('products.*',"cart.Qtt as Qtt","cart.id as cartid")
            ->get();
            return view('cartList',['products'=>$products]);
        }
        function ordernow()
        {
            $userId=Session::get('LoggedUser')['id'];
          $total= $products=DB::table('cart')
            ->join('products','cart.product_id','=','products.id')
             ->where('cart.user_id',$userId)
           ->sum('products.price');
            
            return view('ordernow')->with('total',$total);
        }
        function orderplace(Request $req)
        {
            return $req->input();
        }
        function addprod()
        {
            return view('addprod');
        }
        function addimage(Request $req )
        {
            if($req->Session()->has('LoggedUser'))
            {
            $pros=new userprod;
            $pros->name=$req->name;
            $pros->price=$req->price;
            $pros->category=$req->category;
            $pros->description=$req->description;
            $pros->user_id=$req->Session()->get('LoggedUser')['id'];
            $products=new Product;
            $products->name=$req->name;
            $products->price=$req->price;
            $products->category=$req->category;
            $products->description=$req->description;

            if($req->hasfile('gallery'))
            {
                $file=$req->file('gallery');
                $extension=$file->getClientOriginalExtension();
                $filename=time().'.'.$extension;
                $file->move('uploads/produit/',$filename);
                $products->gallery =$filename;
                $pros->gallery =$filename;
            }else
            {
                return $req;

                $products->image='';
                $pro->image='';
            }
            $products->save();
            $pros->save();
        return  redirect('/listPro')->with('pros',$pros);
    }else 
    {
        return redirect('/login');
    }
    }
     function listPro()
     {
         $pros=userprod::all();
         return view ('listProd')->with('pros',$pros);
     }

      function sup($id)
      {
          $products=Product::find($id);
          $products->delete();
         
          $pros=userprod::find($id);
          $pros->delete();
         
          return redirect('/listPro')->with('pros',$pros);
      }
        function update(Request $req,$id)
     {
         $pros=userprod::find($id);
         $pros->user_id=$req->Session()->get('LoggedUser')['id'];
         $pros->name=$req->name;
         $pros->price=$req->price;
         $pros->category=$req->category;
         $pros->description=$req->description;
         $products= Product::find($req->category);
         $products->name=$req->name;
         $products->price=$req->price;
         $products->category=$req->category;
         $products->description=$req->description;
         if($request->hasfile('image'))
         {
             $file=$request->file('image');
             $extension=$file->getClientOriginalExtension();
             $filename=time().'.'.$extension;
             $file->move('uploads/produit/',$filename);
             $products ->image =$filename;
             $pros->image =$filename;
         }
         $products->save();
         return redirect('/listProd')->with('pros',$pros);
     }
      function edit($id)
     {
        $pros=userprod::find($id);
         return view ('updateform')->with('pros',$pros);
     }
     public function  handlePayment()
     { 
        $userId=Session::get('LoggedUser')['id'];
        $products=DB::table('cart')
        ->join('products','cart.product_id','=','products.id')
        ->where('cart.user_id',$userId)
        ->select('products.*',"cart.Qtt as Qtt","cart.id as cartid")
        ->get();
      $data = [];
      $data['items'] = [];
      
      foreach ($products as $item)
      {
          array_push($data['items'],[
           'name'=>$item->name,
           'price'=> $item->price,
      
           'qtt'=>$item->Qtt,
           'userId'=> $userId,
           'prodid'=>$item->id
           
          ]);
      }
    
      $data['invoice_id'] =  Session::get('LoggedUser')['id'];
     
      $data['invoice_description'] = "Commande #{$data['invoice_id']} ";
      
   $data['return_url'] = url('success.payment');
     
      $data['cancel_url'] = url('cancel.payment');
    
      $total = 10;
     
    //   foreach($data['items'] as $item) {
    //       $total +=$item['qtt'] ;
    //   }
      
     $data['total'] = $total;
    
      $paypalModule = new ExpressCheckout;
    //   return    $paypalModule ;
    
      $res =$paypalModule->setExpressCheckout($data);
      $res =$paypalModule->setExpressCheckout($data,true);
      
      return redirect($res['paypal_link']);
    
    
      
     }
     public function paymentCancel()
     {
         return redirect()->route('cartList')->with([
             'info'=>'Vous annuler le paiement'
         ]);
     }
     public function paymentSuccess(Request $request)
     {
      $paypalModule=new  ExpressCheckout;
      $response =$paypalModule-> getExpressCheckoutDetails($request->token);
      if(in_array(strtoupper($response['ACK']),['SUCCESS','SUCCESSWITHWARNING']))
      {
          foreach (   $products as $item)
          {
             order::create([
            
                  'user_id'=>$item-> userId,
                  'name'=>$item->name,
                'price'=>$item->price ,
                  'qty'=>$item->Qtt,
           
                'total'=>2,
                  'prodid'=>$item->id,
                  'paid'=>1
                 ]);
             
                //  Cart::clear();
          }
          return redirect()->route('cartList')->with([
              'success'=>'Paiement effectue avec succes'
          ]);
      }
         
     }
     function orderList()
     {
        
        
        $userId=Session::get('LoggedUser')['id'];
         $userprod=DB::table('orders')
         ->join('userprod','orders.prodid','=','userprod.id')
         ->where('orders.artisanid',$userId)
         ->select("orders.*")
         ->get();
         return view('orderList',['userprod'=>$userprod]);
     }
}
