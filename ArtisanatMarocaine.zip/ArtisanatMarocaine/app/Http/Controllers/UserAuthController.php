<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Validator;

class UserAuthController extends Controller
{
    function accueil()
    {
       return view('accueil') ;
    }
    function login()
    {
       return view('auth.login') ;
    }
    function register()
    {
       return view('auth.register') ;
    }
    function create(Request $request)
    {
        $request ->validate([
            'nom'=>'required',
            'prenom' => 'required',
            'adresse'=>'required',
            'phone' => 'required',
            'role' => 'required',
            'email'=>'required|email|unique:users',
            'password'=>'required|min:5|max:12',
        ]);
        $user =new User;
        $user->nom=$request->nom;
        $user->prenom=$request->prenom;
        $user->adresse=$request->adresse;
        $user->phone=$request->phone;
        $user->role=$request->role;
        $user->email=$request->email;
        $user->password=Hash::make($request->password);
        $query=$user->save();
        if($query)
        {
            return redirect('/');
        }else
        {
            return back()->with('fail','Something went wrong');
        }
    }
    
  function test(Request $request)
  {
    $request ->validate([
      
        'email'=>'required|email',
        'password'=>'required|min:5|max:12'
    ]);
   
    $user =User::where('email','=',$request->email)->first();
    if($user)
    {
        if(Hash::check($request->password,$user->password))
        {
               $request->Session()->put('LoggedUser',$user);
               return redirect('/');
        }else
        {
            $request->session()->flash('fail', 'Invalid Username or Password');
return view('auth.login');
            // return back()->with('fail','Invail password');
        }
    }else
    {
        $request->session()->flash('fail', 'Invalid Username or Password');
return view('auth.login');
        // return redirect()->back()->with('fail','No account found for this email');
    }
  }
  function profile ()
  {
    if(Session()->has('LoggedUser'))
    {
        $user =User::where('id','=',Session('LoggedUser'))->first();
        $data=[
            'LoggedUserInfo'=>$user
        ];
    }
   return view('profile',$data) ;
  }
}
