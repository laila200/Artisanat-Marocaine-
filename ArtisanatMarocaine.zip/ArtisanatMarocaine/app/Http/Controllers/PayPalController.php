<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Srmklive\PayPal\Services\ExpressCheckout;
use App\Models\Product;
use App\Models\Cart;
use Session;
use Illuminate\Support\Facades\DB;
class PayPalController extends Controller
{
/**
 * Responds with a welcome message with instructions
 *
 * @return \Illuminate\Http\Response
 */
public function payment()
{
 
    
$data = [];
$data['items'] = [
    [
    'name' => 'web-tuts.com',
    'price' => 100,
    'desc' => 'Description for web-tuts.com',
    'qty' => 1
    ]
    ];
    $userId=Session::get('LoggedUser')['id'];
    $products=DB::table('cart')
    ->join('products','cart.product_id','=','products.id')
    ->where('cart.user_id',$userId)
    ->select('products.*',"cart.Qtt as Qtt","cart.id as cartid")
    ->get();
    // foreach ($products as $item)
    //   {
       
    //     array_push($data['items'],[
    //        'name'=>$item->name,
    //        'price'=> $item->price,
      
    //        'qtt'=>$item->Qtt,
    //        'userId'=> $userId,
    //        'prodid'=>$item->id
           
    //       ]);
    //   }
  
 $data['invoice_id'] =  $userId ;
 $data['invoice_description'] = "Order #{$data['invoice_id']} Invoice";
 $data['return_url'] = route('payment.success');
 $data['cancel_url'] = route('payment.cancel');
 $data['total'] = 100;
 $provider = new ExpressCheckout;
 $response = $provider->setExpressCheckout($data);
 $response = $provider->setExpressCheckout($data, true);
return redirect($response['paypal_link']);
}
/**
 * Responds with a welcome message with instructions
 *
 * @return \Illuminate\Http\Response
 */
public function cancel()
{
 dd('Your payment is canceled. You can create cancel page here.');
}
/**
 * Responds with a welcome message with instructions
 *
 * @return \Illuminate\Http\Response
 */
public function success(Request $request)
{
    return' hi';
 $response = $provider->getExpressCheckoutDetails($request->token);
if (in_array(strtoupper($response['ACK']), ['SUCCESS', 'SUCCESSWITHWARNING'])) {
 dd('Your payment was successfully. You can create success page here.');
}
 dd('Something is wrong.');
}
}
