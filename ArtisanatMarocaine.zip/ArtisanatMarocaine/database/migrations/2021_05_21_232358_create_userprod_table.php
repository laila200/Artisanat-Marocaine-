<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserprodTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('userprod', function (Blueprint $table) {
            $table->id();
            $table->string("name");
            $table->string("price");
            $table->integer('user_id');
            $table->string("category");
            $table->string("description");
            $table->mediumText("gallery")->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('userprod');
    }
}
