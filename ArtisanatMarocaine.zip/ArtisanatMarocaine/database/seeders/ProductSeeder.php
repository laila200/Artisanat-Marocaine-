<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('products')->insert([
            [
            'name'=>'Pr 1',
            'price'=>'135',
            'description'=>'Poudre de Moringa Bio 150g',
             'category'=>'Coffrets beauté naturelle',
             'gallery'=>'https://www.infomediaire.net/wp-content/uploads/2017/07/artisanat.jpg'
            ],
            [
                'name'=>'pr2',
                'price'=>'135',
                'description'=>'Poudre de Moringa Bio 150g',
                 'category'=>'Coffrets beauté naturelle',
                 'gallery'=>'https://quid.ma/uploads/articles/large/9678.jpg'
            ],
            [
                'name'=>'pr3',
                'price'=>'135',
                'description'=>'Poudre de Moringa Bio 150g',
                 'category'=>'Coffrets beauté naturelle',
                 'gallery'=>'https://www.voyageurs-du-net.com/wp-content/uploads/2012/08/poteries.jpg'
                ]
         ] );
    }
}
