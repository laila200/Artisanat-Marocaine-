<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
        <title>Laravel 5.8 PayPal Integration Tutorial - ItSolutionStuff.com</title>
  
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha256-YLGeXaapI0/5IgZopewRJcFXomhRMlYYjugPLSyNjTY=" crossorigin="anonymous" />
  
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }
            .content {
                margin-top: 100px;
                text-align: center;
            }
        </style>
    </head>
    <body>
    <nav class="nav">
              @if(Session::has('LoggedUser'))
                @if(Session::get('LoggedUser')['role']=='user')
                <div class="wrapper container">
                  <div class="logo"><a href="">Artisanat Marocain</a></div>
                  <ul class="nav-list">
                    <div class="top">
                      <label for="" class="btn close-btn"><i class="fas fa-times"></i></label>
                    </div>
                    <li><a href="/">Accueil</a></li>
                    <li><a href="/index">Products</a></li>
                    <li>
                        <a href="" class="desktop-item">Artisanat <span><i class="fas fa-chevron-down"></i></span></a>
                          <input type="checkbox" id="showMega" />
                          <label for="showMega" class="mobile-item">Artisanat <span><i class="fas fa-chevron-down"></i></span></label>
                          <div class="mega-box" style="height: 370px;">
                            <div class="content">
                              <!-- <div class="row" style="background-color:#ff4545; ">
                                <img src="https://www.epicerieverte.ma/upload/prod_1611861040.png" alt="" /> 
                              </div> -->
                              <div class="row">
                                <header style="text-align:center">
                                
                                  <form action="/search">
                                  @csrf
                                    <button type="submit"  style="border:none;">  
                                    <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Assiettes" readonly>Assiettes
                                    </button>
                                  </form>
                                  </header>
                                  <img src="https://www.epicerieverte.ma/upload/cat_1612437810.jpeg" width="200px" height="200px" alt="">
                                  
                              </div>
                            
                              <div class="row">
                            
                                <header style="text-align:center">
                                <form action="/search">
                                @csrf
                                  <button type="submit"  style="border:none;">  
                                  <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Bols" readonly>Bols
                                  </button>
                                </form>
                                </header>
                                <img src="https://www.epicerieverte.ma/upload/cat_1612437557.jpg" alt="">
                              
                              </div>                           
                              <div class="row">
                                <header style="text-align:center">
                                    <form action="/search">
                                    @csrf
                                      <button type="submit"  style="border:none;">  
                                      <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Poterie" readonly>Poterie
                                      </button>
                                    </form>
                                
                                </header>
                              <img src="https://www.epicerieverte.ma/upload/cat_1612435361.jfif" alt="">
                            </div>
                            <div class="row">
                              <header style="text-align:center">
                                <form action="/search">
                                    @csrf
                                      <button type="submit"  style="border:none;">  
                                      <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Tajines" readonly>Tajines
                                      </button>
                                    </form>
                              </header>
                              <img src="https://www.epicerieverte.ma/upload/cat_1612437458.jpg" alt="">
                            </div>
                            <div class="row">
                              <header style="text-align:center">
                              <form action="/search">
                                    @csrf
                                      <button type="submit"  style="border:none;">  
                                      <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Théière" readonly>Théières
                                      </button>
                                    </form>
                              </header>
                              <img src="https://www.epicerieverte.ma/upload/cat_1612437941.jpg" alt="">
                            </div>
                            <div class="row">
                                <header style="text-align:center">
                                      <form action="/search">
                                        @csrf
                                          <button type="submit"  style="border:none;">  
                                          <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Assiettes" readonly>Assiettes
                                          </button>
                                        </form>
                                </header>
                                  
                          
                              <img src="https://www.epicerieverte.ma/upload/cat_1612437724.jpg" alt="">
                            </div>
                            

                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="" class="desktop-item">{{Session::get('LoggedUser')['prenom']}}  {{Session::get('LoggedUser')['nom']}}<span><i class="fas fa-chevron-down"></i></span></a>
                        <input type="checkbox" id="showdrop2" />
                        <label for="showdrop2" class="mobile-item"> <span>nom<i class="fas fa-chevron-down"></i></span></label>
                        <ul class="drop-menu2">
                            <li><a href="logout">Déconnecter</a></li>
                            <li><a href="">Contact</a></li>
                            <li><a href="/profile">Profile</a></li>
                            <li><a href="cartList">Panier</a></li>
                        </ul>
                    </li>
                    <!-- icons -->
                    <li class="icons">
                        <span>
                          <img  width="35px" style="margin-top:6px" height="35px" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAhFBMVEX///8zMzP5+fkrKyskJCTW1tYvLy8aGhrZ2dkcHBwfHx8nJyf09PTf398qKiolJSWEhITo6OjDw8MVFRXMzMySkpJhYWE3Nzfs7OxRUVGenp6tra3CwsJZWVlAQEBxcXGWlpZFRUWHh4e3t7d8fHxnZ2ekpKRwcHAPDw9dXV1KSkqysrLQKU5XAAAF9ElEQVR4nO2d6VLjOhBG8SbHcpx9h4QECJMJ7/9+F9ztwFyWSEFfJFf1+TFVZIyqG0u927m5EQRBEARBEARBEARBEARBEARBEARBEARBEARBEARBaC/DbDIajbKhbzkgxJPtUheaKI7TUexbIrd0BqooVXRClUX5NPEtlTtGs6KMPtEr1ne+JXNDNdPJZ/3qO6nXHd/SOWCVf6NfreNh6lu+39Kd6f/ppP79Wa/bbVmrTe/DwdP5eL7bzfOx/vBpMs98S/kLst7pjiU6GjxW9PHwbjB/P5sqb69R7aSNgkrvR//+32SfnnQs2qriImoU1OsvdMhmxelsVteXzgXrpNmGz19fcHvgP4HatTLCeUhZ/OhbU3IyROX9NSVzxCRnE7P5wR0slqziuIXhzYZ2oJr/6O+6zWWb7rUEc8Uze/ryjBEZ8nXp9ipiuSNmM5k/nrtyxBZVLa4hlztuycwk+/OXDijvSFd4qVyypOOlDYLOReP48VI5JKOtVxplDqs+RTaj85eGw5R2XmKUN3RpR/ee0FK55Fhv0sTQjw/IKSqsTE4ZjukUGrpxDg7SFiX8j+TklKkXJ7OU3kKFcsq2PoZqaXr9fdK2g7hPzC3pG2RN1V+kTG7Z1dsuPRvPNNzVu1od25NDkYPTxg6uQ6amRdE3mdLCuMQ0JA3n7QlNScPc2PovOMEIWsNu9k4n4l1KP31PxWTz+hd2pw+qKrQNO5nlefEOh9K6/iE/T/ML79eOx8sX30p9ZPtT5f5CVLEP5z6uivMCX0BpHDGgycYQBV8d6sC3asxRnRf2MvIwKsWwWxhMpEphc1T/qy4i+YRqmlMheMiYfJmanbvue7qfiDn/0sahLZCMZMkddwGplFU+uF31Il7qKovaOM4LqNJzdmdcg4dalMS1TRhRQhVCU+qpNgrm2a4hHS4pBxDX/KmNaPpNi/BiKrLQRQAaziifdx0ncyV8HMCkxlpBzHqXnJB5jgkjJrNuXrEwXZcaiwEMMXSp6mResTCF1jUtKgPpbsgiOI+Rl5jzbQ9bhNS5hn8VxEbbs6AYuedcQ/JCff99U+7DK+dWnSOJret1rYGVOika7PlP86lcDRgWWVG863+UaFKAImSadQggueAc4Oh8YcqBzTt0MFiQtfOF6U8XzZ0vbAtvJvetvwlp2HO+sC3PpKHBZJAlPLAydr6wLWzy/jhfuCI3dPCe5FM9BVDYXJCGY+/1RHbM7mtiMTchvZe9QWWaVw4RJi2z5R4WIFMpSntPgfeU5ACGfaiM4T8FBpVpbpqWlv+6/hFTprk5pcDeR8GoYIQ4LXTC/SeICmYPaCbTf2+GoscUYNO3qFjCjvgAKkQ1Ea/JLDyULkUeJaD4zlmL+7zMDp4GLgHR4yMqt7aDM4AeIAPgkUzfKTBncQlgaaoAeU/yORNHjNnz0GnkuYMI3Ep8xH0/DwU0B2ym3fcL7ACa9JjSp77nHuktqhB1esBPe06BgbX3eAcL6m1A9k+WQXSBcWUa2JSHJcg+JpeAPHeBZ8BEfADcH+Yg5wnC6JHugOWiLWYm0BJkyY+eaPOdAtMkBmZyKYwucB9Yeoc1X22ISUNM+2QSwlOJC4qOMTOSGWrMw4YhawgRouIk32uCWJGGB8jiQzoCZq8tQMGPImjI4gt+iN2rhsAyzauGc6AZM4XN3QayOGw41wbYRNQbqAFrK7BOGdd9NQdYprlBdtDNwY5IhjAmPIWmcMgSiSnYNPwhgC7wE7TXHkIXGHtSuAvsfirQghn0oYgX1OyqBWtoSXMUwCD0EuqTm5jQZwqMLbxnwWho/rokO0K4h7avvLLjue+/FMXPlIOmCciO+S163/HQ17STOafDb4zUXiPvmF/w1EsB8PcpIOatLBh88bUObul5frZrgXm90Ae076e5b3OsgsXWs4Kv+xR6F7Xv4cs3VvrjN8i4RJU6jC/4qKbL6PNrgn5PdHzwfQbf+eEFQr/At1aCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCECD/AbIKUAbvKc+3AAAAAElFTkSuQmCC" alt="" />
                          <small class="count d-flex">{{$total}}</small>
                        </span>
                    </li>
                  </ul>
                  <!-- <label for="" class="btn open-btn"></label> -->
            </div>
                @else
                <div class="wrapper container">
                    <div class="logo"><a href="">Artisanat Marocain</a></div>
                    <ul class="nav-list">
                      <div class="top">
                        <label for="" class="btn close-btn"><i class="fas fa-times"></i></label>
                      </div>
                      <li><a href="/">Accueil</a></li>
                      <li><a href="/index">Products</a></li>
                      <li>
                        <a href="" class="desktop-item">Artisanat <span><i class="fas fa-chevron-down"></i></span></a>
                          <input type="checkbox" id="showMega" />
                          <label for="showMega" class="mobile-item">Artisanat <span><i class="fas fa-chevron-down"></i></span></label>
                          <div class="mega-box" style="height: 370px;">
                            <div class="content">
                              <!-- <div class="row" style="background-color:#ff4545; ">
                                <img src="https://www.epicerieverte.ma/upload/prod_1611861040.png" alt="" /> 
                              </div> -->
                              <div class="row">
                                <header style="text-align:center">
                                
                                  <form action="/search">
                                  @csrf
                                    <button type="submit"  style="border:none;">  
                                    <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Assiettes" readonly>Assiettes
                                    </button>
                                  </form>
                                  </header>
                                  <img src="https://www.epicerieverte.ma/upload/cat_1612437810.jpeg" width="200px" height="200px" alt="">
                                  
                              </div>
                            
                              <div class="row">
                            
                                <header style="text-align:center">
                                <form action="/search">
                                @csrf
                                  <button type="submit"  style="border:none;">  
                                  <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Bols" readonly>Bols
                                  </button>
                                </form>
                                </header>
                                <img src="https://www.epicerieverte.ma/upload/cat_1612437557.jpg" alt="">
                              
                              </div>                           
                              <div class="row">
                                <header style="text-align:center">
                                    <form action="/search">
                                    @csrf
                                      <button type="submit"  style="border:none;">  
                                      <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Poterie" readonly>Poterie
                                      </button>
                                    </form>
                                
                                </header>
                              <img src="https://www.epicerieverte.ma/upload/cat_1612435361.jfif" alt="">
                            </div>
                            <div class="row">
                              <header style="text-align:center">
                                <form action="/search">
                                    @csrf
                                      <button type="submit"  style="border:none;">  
                                      <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Tajines" readonly>Tajines
                                      </button>
                                    </form>
                              </header>
                              <img src="https://www.epicerieverte.ma/upload/cat_1612437458.jpg" alt="">
                            </div>
                            <div class="row">
                              <header style="text-align:center">
                              <form action="/search">
                                    @csrf
                                      <button type="submit"  style="border:none;">  
                                      <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Théière" readonly>Théières
                                      </button>
                                    </form>
                              </header>
                              <img src="https://www.epicerieverte.ma/upload/cat_1612437941.jpg" alt="">
                            </div>
                            <div class="row">
                                <header style="text-align:center">
                                      <form action="/search">
                                        @csrf
                                          <button type="submit"  style="border:none;">  
                                          <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Assiettes" readonly>Assiettes
                                          </button>
                                        </form>
                                </header>
                                  
                          
                              <img src="https://www.epicerieverte.ma/upload/cat_1612437724.jpg" alt="">
                            </div>
                            

                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="" class="desktop-item">{{Session::get('LoggedUser')['prenom']}}  {{Session::get('LoggedUser')['nom']}}<span><i class="fas fa-chevron-down"></i></span></a>
                        <input type="checkbox" id="showdrop2" />
                        
                      
                        <label for="showdrop2" class="mobile-item"> <span>nom<i class="fas fa-chevron-down"></i></span></label>
                        <ul class="drop-menu2">
                          <li><a href="logout">Déconnecter</a></li>
                          <li><a href="">Contact</a></li>
                          <li><a href="/addprod">ajouter Produits</a></li>
                          <li><a href="/listPro">Afficher Produits</a></li>
                        </ul>
                      </li>
                      <!-- icons -->
                      <li class="icons">
                 
        
                </li>
                    </ul>
                    <!-- <label for="" class="btn open-btn"></label> -->
                </div>
                @endif
              @else
              <div class="wrapper container">
                    <div class="logo"><a href="">Artisanat Marocain</a></div>
                    <ul class="nav-list">
                      <div class="top">
                        <label for="" class="btn close-btn"><i class="fas fa-times"></i></label>
                      </div>
                      <li><a href="/">Accueil</a></li>
                      <li><a href="/index">Products</a></li>
                      <li>
                        <a href="" class="desktop-item">Artisanat <span><i class="fas fa-chevron-down"></i></span></a>
                          <input type="checkbox" id="showMega" />
                          <label for="showMega" class="mobile-item">Artisanat <span><i class="fas fa-chevron-down"></i></span></label>
                          <div class="mega-box" style="height: 370px;">
                            <div class="content">
                              <!-- <div class="row" style="background-color:#ff4545; ">
                                <img src="https://www.epicerieverte.ma/upload/prod_1611861040.png" alt="" /> 
                              </div> -->
                              <div class="row">
                                <header style="text-align:center">
                                
                                  <form action="/search">
                                  @csrf
                                    <button type="submit"  style="border:none;">  
                                    <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Assiettes" readonly>Assiettes
                                    </button>
                                  </form>
                                  </header>
                                  <img src="https://www.epicerieverte.ma/upload/cat_1612437810.jpeg" width="200px" height="200px" alt="">
                                  
                              </div>
                            
                              <div class="row">
                            
                                <header style="text-align:center">
                                <form action="/search">
                                @csrf
                                  <button type="submit"  style="border:none;">  
                                  <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Bols" readonly>Bols
                                  </button>
                                </form>
                                </header>
                                <img src="https://www.epicerieverte.ma/upload/cat_1612437557.jpg" alt="">
                              
                              </div>                           
                              <div class="row">
                                <header style="text-align:center">
                                    <form action="/search">
                                    @csrf
                                      <button type="submit"  style="border:none;">  
                                      <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Poterie" readonly>Poterie
                                      </button>
                                    </form>
                                
                                </header>
                              <img src="https://www.epicerieverte.ma/upload/cat_1612435361.jfif" alt="">
                            </div>
                            <div class="row">
                              <header style="text-align:center">
                                <form action="/search">
                                    @csrf
                                      <button type="submit"  style="border:none;">  
                                      <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Tajines" readonly>Tajines
                                      </button>
                                    </form>
                              </header>
                              <img src="https://www.epicerieverte.ma/upload/cat_1612437458.jpg" alt="">
                            </div>
                            <div class="row">
                              <header style="text-align:center">
                              <form action="/search">
                                    @csrf
                                      <button type="submit"  style="border:none;">  
                                      <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Théière" readonly>Théières
                                      </button>
                                    </form>
                              </header>
                              <img src="https://www.epicerieverte.ma/upload/cat_1612437941.jpg" alt="">
                            </div>
                            <div class="row">
                                <header style="text-align:center">
                                      <form action="/search">
                                        @csrf
                                          <button type="submit"  style="border:none;">  
                                          <input type="text" name="ga" style="border:none ;cursor: pointer;" value="Assiettes" readonly>Assiettes
                                          </button>
                                        </form>
                                </header>
                                  
                          
                              <img src="https://www.epicerieverte.ma/upload/cat_1612437724.jpg" alt="">
                            </div>
                            

                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="" class="desktop-item"> Client<span><i class="fas fa-chevron-down"></i></span></a>
                        <input type="checkbox" id="showdrop2" />
                        <label for="showdrop2" class="mobile-item">Page <span><i class="fas fa-chevron-down"></i></span></label>
                        <ul class="drop-menu2">
                          <li><a href="/login">login</a></li>
                          <li><a href="/register">regiser</a></li>
                          <!-- <li><a href="/addprod"> </a></li>
                          <li><a href="/listPro">Afficher</a></li> -->
                        </ul>
                      </li>
                      <!-- icons -->
                      <li class="icons">
                        <span>
                          <img  width="35px" style="margin-top:6px" height="35px" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAhFBMVEX///8zMzP5+fkrKyskJCTW1tYvLy8aGhrZ2dkcHBwfHx8nJyf09PTf398qKiolJSWEhITo6OjDw8MVFRXMzMySkpJhYWE3Nzfs7OxRUVGenp6tra3CwsJZWVlAQEBxcXGWlpZFRUWHh4e3t7d8fHxnZ2ekpKRwcHAPDw9dXV1KSkqysrLQKU5XAAAF9ElEQVR4nO2d6VLjOhBG8SbHcpx9h4QECJMJ7/9+F9ztwFyWSEFfJFf1+TFVZIyqG0u927m5EQRBEARBEARBEARBEARBEARBEARBEARBEARBEARBaC/DbDIajbKhbzkgxJPtUheaKI7TUexbIrd0BqooVXRClUX5NPEtlTtGs6KMPtEr1ne+JXNDNdPJZ/3qO6nXHd/SOWCVf6NfreNh6lu+39Kd6f/ppP79Wa/bbVmrTe/DwdP5eL7bzfOx/vBpMs98S/kLst7pjiU6GjxW9PHwbjB/P5sqb69R7aSNgkrvR//+32SfnnQs2qriImoU1OsvdMhmxelsVteXzgXrpNmGz19fcHvgP4HatTLCeUhZ/OhbU3IyROX9NSVzxCRnE7P5wR0slqziuIXhzYZ2oJr/6O+6zWWb7rUEc8Uze/ryjBEZ8nXp9ipiuSNmM5k/nrtyxBZVLa4hlztuycwk+/OXDijvSFd4qVyypOOlDYLOReP48VI5JKOtVxplDqs+RTaj85eGw5R2XmKUN3RpR/ee0FK55Fhv0sTQjw/IKSqsTE4ZjukUGrpxDg7SFiX8j+TklKkXJ7OU3kKFcsq2PoZqaXr9fdK2g7hPzC3pG2RN1V+kTG7Z1dsuPRvPNNzVu1od25NDkYPTxg6uQ6amRdE3mdLCuMQ0JA3n7QlNScPc2PovOMEIWsNu9k4n4l1KP31PxWTz+hd2pw+qKrQNO5nlefEOh9K6/iE/T/ML79eOx8sX30p9ZPtT5f5CVLEP5z6uivMCX0BpHDGgycYQBV8d6sC3asxRnRf2MvIwKsWwWxhMpEphc1T/qy4i+YRqmlMheMiYfJmanbvue7qfiDn/0sahLZCMZMkddwGplFU+uF31Il7qKovaOM4LqNJzdmdcg4dalMS1TRhRQhVCU+qpNgrm2a4hHS4pBxDX/KmNaPpNi/BiKrLQRQAaziifdx0ncyV8HMCkxlpBzHqXnJB5jgkjJrNuXrEwXZcaiwEMMXSp6mResTCF1jUtKgPpbsgiOI+Rl5jzbQ9bhNS5hn8VxEbbs6AYuedcQ/JCff99U+7DK+dWnSOJret1rYGVOika7PlP86lcDRgWWVG863+UaFKAImSadQggueAc4Oh8YcqBzTt0MFiQtfOF6U8XzZ0vbAtvJvetvwlp2HO+sC3PpKHBZJAlPLAydr6wLWzy/jhfuCI3dPCe5FM9BVDYXJCGY+/1RHbM7mtiMTchvZe9QWWaVw4RJi2z5R4WIFMpSntPgfeU5ACGfaiM4T8FBpVpbpqWlv+6/hFTprk5pcDeR8GoYIQ4LXTC/SeICmYPaCbTf2+GoscUYNO3qFjCjvgAKkQ1Ea/JLDyULkUeJaD4zlmL+7zMDp4GLgHR4yMqt7aDM4AeIAPgkUzfKTBncQlgaaoAeU/yORNHjNnz0GnkuYMI3Ep8xH0/DwU0B2ym3fcL7ACa9JjSp77nHuktqhB1esBPe06BgbX3eAcL6m1A9k+WQXSBcWUa2JSHJcg+JpeAPHeBZ8BEfADcH+Yg5wnC6JHugOWiLWYm0BJkyY+eaPOdAtMkBmZyKYwucB9Yeoc1X22ISUNM+2QSwlOJC4qOMTOSGWrMw4YhawgRouIk32uCWJGGB8jiQzoCZq8tQMGPImjI4gt+iN2rhsAyzauGc6AZM4XN3QayOGw41wbYRNQbqAFrK7BOGdd9NQdYprlBdtDNwY5IhjAmPIWmcMgSiSnYNPwhgC7wE7TXHkIXGHtSuAvsfirQghn0oYgX1OyqBWtoSXMUwCD0EuqTm5jQZwqMLbxnwWho/rokO0K4h7avvLLjue+/FMXPlIOmCciO+S163/HQ17STOafDb4zUXiPvmF/w1EsB8PcpIOatLBh88bUObul5frZrgXm90Ae076e5b3OsgsXWs4Kv+xR6F7Xv4cs3VvrjN8i4RJU6jC/4qKbL6PNrgn5PdHzwfQbf+eEFQr/At1aCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCECD/AbIKUAbvKc+3AAAAAElFTkSuQmCC" alt="" />
                          <small class="count d-flex">0</small>
                        </span>
              
                      </li>
                    </ul>
                    <!-- <label for="" class="btn open-btn"></label> -->
            </div>
              @endif
  </nav>
        <div class="flex-center position-ref full-height">
  
            <div class="content">
                <h1>Laravel 5.8 PayPal Integration Tutorial - ItSolutionStuff.com</h1>
                  
                <table border="0" cellpadding="10" cellspacing="0" align="center"><tr><td align="center"></td></tr><tr><td align="center"><a href="https://www.paypal.com/in/webapps/mpp/paypal-popup" title="How PayPal Works" onclick="javascript:window.open('https://www.paypal.com/in/webapps/mpp/paypal-popup','WIPaypal','toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=1060, height=700'); return false;"><img src="https://www.paypalobjects.com/webstatic/mktg/Logo/pp-logo-200px.png" border="0" alt="PayPal Logo"></a></td></tr></table>
  
                <a href="{{ route('payment') }}" class="btn btn-success">Pay $100 from Paypal</a>
  
            </div>
        </div>
    </body>
</html>