<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserAuthController;
use App\Http\Controllers\ProductController;

 use App\Http\Controllers\PayPalController;
 

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('accueil');
});

Route::get('login',[UserAuthController::class,'login']);
Route::get('index',[ProductController::class,'index']);
Route::get('register',[UserAuthController::class,'register']);
Route::post('create',[UserAuthController::class,'create'])->name('auth.create');
Route::post('test',[UserAuthController::class,'test'])->name('auth.test');
Route::get('profile',[UserAuthController::class,'profile']);
Route::get('detail/{id}',[ProductController::class,'detail']);
Route::POST('addToCart',[ProductController::class,'addToCart']);
Route::get('/logout', function () {
    Session::forget('LoggedUser');
    return view('accueil');
});
Route::get('/lpa', function () {
    Session::forget('LoggedUser');
    return view('pa');
});
 Route::get('payment', [PayPalController::class,'payment'])->name('payment');
Route::get('cancel', [PayPalController::class,'cancel'])->name('payment.cancel');
Route::get('payment/success', [PayPalController::class,'success'])->name('payment.success');

Route::get('cartList',[ProductController::class,'cartList']);
Route::get('ordernow',[ProductController::class,'ordernow']);
Route::post('orderplace',[ProductController::class,'orderplace']);
Route::get('addprod',[ProductController::class,'addprod']);
Route::post('addimage',[ProductController::class,'addimage'])->name('addimage');
Route::get('listPro',[ProductController::class,'listPro']);
Route::get('search',[ProductController::class,'search']);
Route::get('searchA',[ProductController::class,'searchA']);
Route::get('/sup/{id}',[ProductController::class,'sup']);
Route::get('/edit/{id}',[ProductController::class,'edit']);
Route::get('remove/{id}',[ProductController::class,'remove']);
// Route::get('/handle-payment',[ProductController::class,'handlePayment'])->name('make.payment');
// Route::get('/paymentCancel',[ProductController::class,'paymentCancel'])->name('cancel.payment');
Route::get('orderList',[ProductController::class,'orderList']);
Route::post('/editcart/{id}',[ProductController::class,'editcart']);
Route::put('/update/{id}',[ProductController::class,'update'])->name('update');
// Route::get('payment', 'PayPalController@payment')->name('payment');
// Route::get('cancel', 'PayPalController@cancel')->name('payment.cancel');
// Route::get('payment/success', 'PayPalController@success')->name('payment.success');
