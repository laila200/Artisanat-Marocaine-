<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Basic Table</h2>
  <p>The .table class adds basic styling (light padding and only horizontal dividers) to a table:</p>            
  <table class="table">
   
    <tbody>
      <tr>
        <td>Amount</td>
        <td><?php echo e($total); ?>Dh</td>
      
      </tr>
      <tr>
        <td>Tax</td>
        <td>0Dh</td>
      
      </tr>
      <tr>
        <td>Delivery</td>
        <td>20 DH</td>
      </tr>
      <tr>
        <td>total Amount</td>
        <td><?php echo e($total+20); ?></td>
      </tr>
    </tbody>
  </table>
</div>
 <div>
 <!-- <form action="/orderplace" method="post">
 <?php echo csrf_field(); ?>
  <div class="form-group">
    <textarea type="email"  name="address" placeholder="entrer votre email" id="email" ></textarea>
  </div>
  <div class="form-group">
    <label for="pwd">Payment Method</label><br> <br>
    <input type="radio" value="cash" name="payment"><span>online payment</span> <br> <br>
    <input type="radio" value="cash" name="payment"><span>EMI payment</span><br> <br>
    <input type="radio" value="cash" name="payment"><span>Payment on Delivery</span><br> <br>
 
  </div>
  <div class="checkbox">
    <label><input type="checkbox"> Remember me</label>
  </div>
  <button type="submit" class="btn btn-default">Order Now</button>
</form> -->
 </div>
</body>
</html>
<?php /**PATH C:\XamppApp\htdocs\BM\ArtisanatMarocaine\resources\views/ordernow.blade.php ENDPATH**/ ?>